import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'BranchTale | Etkileşimli hikayeler',
  description: 'Dallanıp budaklanan hikayeler yazın ve keşfedin',
}